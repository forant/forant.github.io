# @getrefino/react

React layer for **Refino** — the site owner edits the website's visible copy in
place on the rendered page, and the repository stays the source of truth.

Installed for you by `npx @getrefino/cli init`.

```tsx
<RefinoProvider content={copy} editing={isOwner} endpoint="/api/copy" onExit={...}>
  <EditableText id="home.hero.title" as="h1" className="hero__title" />
</RefinoProvider>
```

In normal mode `EditableText` renders a plain semantic element — exactly
`<h1 class="hero__title">…</h1>`, with no editor code path. In edit mode the
same element becomes editable in place and a small toolbar appears (Save,
Revert, Revert all, Exit). Use `useCopyEditor()` with `toolbar={false}` for
custom controls.

Editor CSS is scoped to `data-refino-*` attributes and `refino-*` class names,
so host styles are untouched.

<https://refino.dev>
