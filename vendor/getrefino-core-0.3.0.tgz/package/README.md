# @getrefino/core

Content model, draft state and persistence contracts for **Refino** — in-browser
editing of an existing website's copy, with the repository as the source of
truth. Framework-independent.

Installed for you by `npx @getrefino/cli init`.

Browser-safe main entry: content ids, `parseCopy` / `serializeCopy`,
`applyChanges`, draft helpers, `ContentAdapter`, `planSave`, `createContentApi`.

Node-only entry `@getrefino/core/local-file`: `createLocalFileContentAdapter`
for development.

<https://refino.dev>
